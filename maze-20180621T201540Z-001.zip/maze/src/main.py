import os, sys, pygame
from random import randint
import random
from collections import defaultdict
from utils import argmax
from mdp import *

def get_policy_from_qvalues(Qvalues):
    policy={}
    actions=[(1,0),(0,1),(-1,0),(0,-1)]
    best_score = -10
    best_action=None
    previous_element=None
    for element in Qvalues:
        if(previous_element!=element[0]):
            best_score=-10
        for k in range(len(actions)):
            if(element[1]==None):
                policy[element[0]]=element[1]
                break
            if(element[1]==actions[k]):
                if(Qvalues[element]>best_score):
                    best_action=element[1]
                    best_score = Qvalues[element]
            policy[element[0]]=best_action
        previous_element=element[0]
    return policy
    
class QLearningAgent:
    
    def __init__(self, mdp, Ne, Rplus, alpha=None):

        self.gamma = mdp.gamma    # factor de descuento (definido en el MDP)
        self.terminals = mdp.terminals   # estados terminales (definido en el MDP)
        self.all_act = mdp.actlist
        self.Ne = Ne        # limite de iteraciones de la funcion de exploracion
        self.Rplus = Rplus  # Recompensa que tienen los estados (o q-estados) antes del limite de iteraciones Ne
        self.Q = defaultdict(float)   # almacena los q-valores
        self.Nsa = defaultdict(float) # almacena la tabla de frecuencias state-action
        self.s = None    # estado previo
        self.a = None    # accion previa
        self.r = None    # recompensa previa

        if alpha:
            self.alpha = alpha
        else:
            self.alpha = lambda n: 1./(1+n)  # udacity video

    def f(self, u, n):
        """ Exploration function. Returns fixed Rplus until agent has visited state-action a Ne number of times"""
        if n < self.Ne:
            return self.Rplus
        else:
            return u

    def actions_in_state(self, state):
        """ Returns actions possible in given state. Useful for max and argmax. """
        if state in self.terminals:
            return [None]
        else:
            return self.all_act

    def __call__(self, percept):    # Al llamar al agente como funcion se ejecuta este codigo
        s1, r1 = self.update_state(percept)
        Q, Nsa, s, a, r = self.Q, self.Nsa, self.s, self.a, self.r
        alpha, gamma, terminals = self.alpha, self.gamma, self.terminals,
        actions_in_state = self.actions_in_state

        if s in terminals:
            Q[s, None] = r1
        if s is not None:
            Nsa[s, a] += 1
            Q[s, a] += alpha(Nsa[s, a]) * (r + gamma * max(Q[s1, a1]
                                           for a1 in actions_in_state(s1)) - Q[s, a])
        if s in terminals:
            self.s = self.a = self.r = None
        else:
            self.s, self.r = s1, r1
            self.a = argmax(actions_in_state(s1), key=lambda a1: self.f(Q[s1, a1], Nsa[s1, a1]))
        return self.a

    def update_state(self, percept):
        ''' To be overridden in most cases. The default case
        assumes the percept to be of type (state, reward)'''
        return percept


class StackList(object):
    def __init__(self):
        self._data = []

    def add(self, level):
        if len(level):
            self._data.insert(0, level)

    def pop(self):
        if not self._data:
            return None
        item = self._data[0].pop()
        if len(self._data[0]) == 0:
            self._data.pop(0)
        return item

class Rectangulo(pygame.sprite.Sprite):
    def __init__(self,pos,color):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface((16, 16)).convert()
        self.image.fill(color)
        self.rect = self.image.get_rect(center=pos)


class Maze(pygame.sprite.Sprite):

    """
    ## MAZE GENERATOR ##
    Based on Depth-first search algorithm:
    http://en.wikipedia.org/wiki/Maze_generation_algorithm#Depth-first_search
      1. Start at a particular cell and call it the "exit."
      2. Mark the current cell as visited, and get a list of its neighbors.
         For each neighbor, starting with a randomly selected neighbor:
           1. If that neighbor hasn't been visited, remove the wall between
              this cell and that neighbor, and then recurse with that neighbor as
              the current cell.
    __author__ = "Leonardo Vidarte"
    """

    def __init__(self, screen, width=21, height=21, exit_cell=(1, 1)):
        pygame.sprite.Sprite.__init__(self)
        if width % 2 == 0:
            width += 1
        if height % 2 == 0:
            height += 1
        self.width = width
        self.height = height
        self.start_cell = None
        self.exit_cell = exit_cell
        self.steps = 0
        self.maze = None
        self.screen = screen
        self.create()

    def create(self):
        self.maze = [[1, ] * self.width  for _ in range(self.height)] # full of walls

        visited = []
        stack = StackList()
        item = (None, self.exit_cell)
        while item is not None:
            prev, cell = item
            if cell not in visited:
                x, y = cell
                self.maze[y][x] = 0
                if prev and cell:
                    self._remove_wall(prev, cell)
                neighbors = [x for x in self._get_neighbors(cell) if x not in visited]
                random.shuffle(neighbors)
                stack.add([(cell, x) for x in neighbors])
                visited.append(cell)
            item = stack.pop()

    def __str__(self):
        res = ''
        for row in self.maze:
            for col in row:
                res += col and '##' or '  '
            res += '\n'
        return res

    def _get_neighbors(self, cell):
        x, y = cell
        neighbors = []

        # Left
        if x - 2 > 0:
            neighbors.append((x-2, y))
        # Right
        if x + 2 < self.width:
            neighbors.append((x+2, y))
        # Up
        if y - 2 > 0:
            neighbors.append((x, y-2))
        # Down
        if y + 2 < self.height:
            neighbors.append((x, y+2))

        return neighbors

    def _remove_wall(self, cell, neighbor):
        """
        Remove the wall between two cells
        Example:
          Given the cells a and b
          The wall between them is w
          # # # # #
          # # # # #
          # a w b #
          # # # # #
          # # # # #
        """
        x0, y0 = cell
        x1, y1 = neighbor
        # Vertical
        if x0 == x1:
            x = x0
            y = int((y0 + y1) / 2)
        # Horizontal
        if y0 == y1:
            x = int((x0 + x1) / 2)
            y = y0

        # remove walls
        self.maze[y][x] = 0

        self.start_cell = neighbor
        self.steps += 2

    def _update_start_cell(self, cell, depth):
        if depth > self.recursion_depth:
            self.start_cell = cell
            self.steps = depth * 2 # wall + cell

    def crearRectangulos(self):
        self.lista_rect=list()
        for x in range(len(self.maze[0])):
            for y in range(len(self.maze)):
                if(self.maze[y][x]==1):
                    self.lista_rect.append(Rectangulo((16*x+1,16*y+1),(255,255,255)))
                elif(self.maze[y][x]==2):
                    self.lista_rect.append(Rectangulo((16*x+1,16*y+1),(0,255,0)))


    def buscarColisiones(self, x_ball, y_ball):
        if(self.maze[y_ball][x_ball]==1):
            return 1
        elif(self.maze[y_ball][x_ball]==2):
            return 2
        return 0

    def show(self, verbose=False):
        sprites=pygame.sprite.Group()
        for rectangulo in self.lista_rect:
            sprites.add(rectangulo)
            sprites.draw(self.screen)

    def showTerminal(self):
        for x in range(len(self.maze[0])):
            print(self.maze[x])

    def ponerMetaEn(self, x, y):
        self.maze[y][x]=2
        
    def generar_mdp(self):
        self.recompensas_xy = []
        for y in range(len(self.maze[0])):
            recompensas_y = []
            for x in range(len(self.maze[1])):
                if(self.maze[y][x]==1):
                    recompensas_y.append(None)
                elif(self.maze[y][x]==0):
                    recompensas_y.append(-0.04)
                elif(self.maze[y][x]==2):
                    recompensas_y.append(+1)
            print(recompensas_y)
            self.recompensas_xy.append(recompensas_y)
        #print(self.recompensas_xy)
        self.grid_mdp = GridMDP(self.recompensas_xy,
                    terminals=[(7,7)], 
                    gamma=0.9, init=(1,1))



class Ball(pygame.sprite.Sprite):
    def __init__(self, grid_mdp, pos=(0, 0)):
        pygame.sprite.Sprite.__init__(self)
        # Incluimos esta linea
        self.pos = pos
        self.image = pygame.Surface((15, 15)).convert()
        self.image.fill((255, 0, 0))
        # Modificamos esta linea
        self.rect = self.image.get_rect(center=self.pos)
        self.speed_x = 0
        self.speed_y = 0
        self.last_move = 0
        self.map_x = 1
        self.map_y = 1
        self.moved_back = 1
        self.q_agent = QLearningAgent(grid_mdp, Ne=10, Rplus=2, alpha=lambda n: 60./(59+n))

    # Agregamos esta funcion
    def reset(self):
        self.rect = self.image.get_rect(center=self.pos)

    def neg_y(self):
        self.speed_y += -16
        self.last_move = 0
        self.map_y += -1
        self.moved_back = 0
    def neg_x(self):
        self.speed_x += -16
        self.last_move = 1
        self.map_x += -1
        self.moved_back = 0

    def pos_y(self):
        self.speed_y += 16
        self.last_move = 2
        self.map_y += 1
        self.moved_back = 0

    def pos_x(self):
        self.speed_x += 16
        self.last_move = 3
        self.map_x += 1
        self.moved_back = 0

    def move_back(self):
        if(self.last_move==0):
            self.pos_y()
            self.moved_back = 1
        elif(self.last_move==1):
            self.pos_x()
            self.moved_back = 1
        elif(self.last_move==2):
            self.neg_y()
            self.moved_back = 1
        elif(self.last_move==3):
            self.neg_x()
            self.moved_back = 1


    def start(self, speed_x, speed_y):
        self.speed_x = speed_x
        self.speed_y = speed_y

    def stop(self):
        self.speed_x = 0
        self.speed_y = 0

    def update(self):
        self.rect.move_ip(self.speed_x, self.speed_y)

    def randomMove(self):
        move = randint(0,3)
        if (self.moved_back == 0):
            if(self.last_move==0):
                self.neg_y()
            elif(self.last_move==1):
                self.neg_x()
            elif(self.last_move==2):
                self.pos_y()
            elif(self.last_move==3):
                self.pos_x()
        elif(move==0):
            self.neg_y()
        elif(move==1):
            self.pos_x()
        elif(move==2):
            self.pos_y()
        elif(move==3):
            self.neg_x()

    def moverse(self, policy):
        pos1 = self.map_x
        pos2 = 14-self.map_y
        accion=policy[(pos1,pos2)]
        #print(accion)
        if accion==(1,0):
            self.pos_x()
        if accion==(0,1):
            self.neg_y()
        if accion==(-1,0):
            self.neg_x()
        if accion==(0,-1):
            self.pos_y()
                    
    def take_single_action(self, mdp, s, a):
        ''' Ejecuta accion a en estado s del entorno mdp y retorna el nuevo estado. 
            El nuevo estado depende de las probabilidades de transicion del mdp'''
        x = random.uniform(0, 1)
        cumulative_probability = 0.0
        for probability_state in mdp.T(s, a):
            probability, state = probability_state
            cumulative_probability += probability
            if x < cumulative_probability:
                break
        return state
                    
    def run_single_trial(self, mdp):
        current_state = mdp.init
        while True:
            current_reward = mdp.R(current_state)
            percept = (current_state, current_reward)
            next_action = self.q_agent(percept)
            if next_action is None:
                break
            current_state = self.take_single_action(mdp, current_state, next_action)

def main():
    pygame.init()

    size = width, height = 350, 350
    screen = pygame.display.set_mode(size)
    pygame.display.set_caption('Maze')
    try:
        filename = os.path.join(
	    os.path.dirname(__file__),
	    'assets',
	    'graphics',
	    'fondo.jpeg')
        background = pygame.image.load(filename)
        background = background.convert()
    except pygame.error as e:
        print ('Cannot load image: ', filename)
        raise SystemExit(str(e))

    maze = Maze(screen, 15, 15)
    maze.ponerMetaEn(7,7)
    maze.crearRectangulos()
    maze.generar_mdp()

    # Insertamos esta linea aqui
    ball = Ball( maze.grid_mdp,(16,16))

    sprites = pygame.sprite.Group(ball)

    clock = pygame.time.Clock()
    fps = 60 #1200 #60

    pygame.key.set_repeat(1, int(1000/fps))

    maze.showTerminal()

    stay = 1

    num_pasos = 0
    #print(maze.grid_mdp)
    for i in range(20):
        ball.run_single_trial(maze.grid_mdp)   
    #print(ball.q_agent.Q)
    policy = best_policy(maze.grid_mdp, value_iteration(maze.grid_mdp, .001))
    #policy=get_policy_from_qvalues(ball.q_agent.Q)
    for e in policy:
        print("estado")
        print(e)
        print("accion")
        print(policy[e])
    print("Entrenamiento terminado")
    
    while 1:
        clock.tick(fps)

        ball.stop()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                 pygame.quit()
                 return
            #elif event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
             #    stay=0
        
        #while(not( event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE )):
         #   pass
        
        num_pasos += 1
        ball.moverse(policy)
        #ball.randomMove()
        
        if (maze.buscarColisiones(ball.map_x, ball.map_y)==1):
            ball.move_back()
        elif(maze.buscarColisiones(ball.map_x, ball.map_y)==2):
            stay=0
            print(num_pasos)
            while(1):
                pass

#        for rectangulo in maze.lista_rect:
#           if ball.rect.colliderect(rectangulo) or ball.rect.colliderect(rectangulo):
#                ball.move_back()
#                break

        screen.blit(background, (0, 0))
        sprites.update()
        sprites.draw(screen)
        maze.show()
        pygame.display.flip()

    #print(num_pasos)
    pygame.quit()

if __name__ == '__main__':
    main()
